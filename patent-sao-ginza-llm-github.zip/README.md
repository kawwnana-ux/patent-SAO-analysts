# 日本語特許請求項 SAO 構造分析

GiNZAによる日本語構文解析とLLMによる意味解析を組み合わせて、
日本語特許請求項から技術的な構成要素と構成要素間の関係を抽出するStreamlitアプリです。

## 解析方式

### GiNZA + LLM（推奨）
1. GiNZAで形態素・品詞・係り受け等の構文情報を取得
2. GiNZAの抽出結果を候補としてLLMへ提示
3. LLMが請求項本文を優先し、文脈を考慮して構成要素・関係を修正・統合
4. SAO形式の関係を返す

### GiNZAのみ
GiNZAを使った従来方式です。
卒業論文で「GiNZAのみ」と「GiNZA + LLM」を比較するために残しています。

## Streamlit Cloud

1. GitHubへ `app.py`, `patent_pipeline.py`, `requirements.txt`, `.python-version` をアップロード
2. Streamlit CloudでアプリをDeploy
3. Settings → Secrets に以下を登録

```toml
OPENAI_API_KEY = "実際のAPIキー"
```

必要に応じてモデル名も設定できます。

```toml
OPENAI_MODEL = "gpt-5.6-luna"
```

## 注意

- `OPENAI_API_KEY` はGitHubへ絶対にアップロードしないでください。
- `.streamlit/secrets.toml.example` は設定例です。
- LLMが利用できない場合、ハイブリッド解析はGiNZAへ自動フォールバックします。
